package b4a.HC05LedOnOff;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class bluetoothasynchstream extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.HC05LedOnOff.bluetoothasynchstream");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.HC05LedOnOff.bluetoothasynchstream.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.Serial.BluetoothAdmin _admin = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astreams = null;
public anywheresoftware.b4a.objects.Serial _serial = null;
public Object _mparent = null;
public String _meventname = "";
public anywheresoftware.b4a.objects.LabelWrapper _lblstatus = null;
public anywheresoftware.b4a.objects.collections.List _founddevices = null;
public boolean _bluetoothstate = false;
public boolean _connectionstate = false;
public boolean _devicefound = false;
public String _charset = "";
public anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
public String _state = "";
public boolean _connected = false;
public b4a.HC05LedOnOff.main _main = null;
public b4a.HC05LedOnOff.starter _starter = null;
public static class _nameandmac{
public boolean IsInitialized;
public String Name;
public String Mac;
public void Initialize() {
IsInitialized = true;
Name = "";
Mac = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _admin_devicefound(String _name,String _macaddress) throws Exception{
b4a.HC05LedOnOff.bluetoothasynchstream._nameandmac _nm = null;
 //BA.debugLineNum = 100;BA.debugLine="Private Sub Admin_DeviceFound (Name As String, Mac";
 //BA.debugLineNum = 102;BA.debugLine="Log(Name & \":\" & MacAddress)";
__c.LogImpl("4851970",_name+":"+_macaddress,0);
 //BA.debugLineNum = 103;BA.debugLine="Dim nm As NameAndMac";
_nm = new b4a.HC05LedOnOff.bluetoothasynchstream._nameandmac();
 //BA.debugLineNum = 104;BA.debugLine="nm.Name = Name";
_nm.Name /*String*/  = _name;
 //BA.debugLineNum = 105;BA.debugLine="nm.Mac = MacAddress";
_nm.Mac /*String*/  = _macaddress;
 //BA.debugLineNum = 106;BA.debugLine="foundDevices.Add(nm)";
_founddevices.Add((Object)(_nm));
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public String  _admin_discoveryfinished() throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Private Sub Admin_DiscoveryFinished";
 //BA.debugLineNum = 135;BA.debugLine="CallSub(Main, \"DiscoverFinished\")";
__c.CallSubNew(ba,(Object)(_main.getObject()),"DiscoverFinished");
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return "";
}
public String  _admin_statechanged(int _newstate,int _oldstate) throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Private Sub Admin_StateChanged (NewState As Int, O";
 //BA.debugLineNum = 145;BA.debugLine="Log(\"State changed: \" & NewState)";
__c.LogImpl("4983041","State changed: "+BA.NumberToString(_newstate),0);
 //BA.debugLineNum = 146;BA.debugLine="lblStatus.Text = \"State changed: \" & NewState";
_lblstatus.setText(BA.ObjectToCharSequence("State changed: "+BA.NumberToString(_newstate)));
 //BA.debugLineNum = 147;BA.debugLine="BluetoothState = NewState = Admin.STATE_ON";
_bluetoothstate = _newstate==_admin.STATE_ON;
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public String  _astreams_error() throws Exception{
 //BA.debugLineNum = 216;BA.debugLine="Private Sub Astreams_Error";
 //BA.debugLineNum = 217;BA.debugLine="Log(\"error: \" & LastException)";
__c.LogImpl("41507329","error: "+BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 218;BA.debugLine="Astreams.Close";
_astreams.Close();
 //BA.debugLineNum = 219;BA.debugLine="CallSubDelayed(mParent, mEventName & \"_Terminated";
__c.CallSubDelayed(ba,_mparent,_meventname+"_Terminated");
 //BA.debugLineNum = 221;BA.debugLine="UpdateState (False)";
_updatestate(__c.False);
 //BA.debugLineNum = 222;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newdata(byte[] _buffer) throws Exception{
String _s = "";
 //BA.debugLineNum = 198;BA.debugLine="Private Sub Astreams_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 200;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 201;BA.debugLine="sb.Append(BytesToString(Buffer, 0, Buffer.Length,";
_sb.Append(__c.BytesToString(_buffer,(int) (0),_buffer.length,_charset));
 //BA.debugLineNum = 202;BA.debugLine="Dim s As String = sb.ToString";
_s = _sb.ToString();
 //BA.debugLineNum = 204;BA.debugLine="CallSubDelayed2(mParent, mEventName & \"_NewText\",";
__c.CallSubDelayed2(ba,_mparent,_meventname+"_NewText",(Object)(_s));
 //BA.debugLineNum = 206;BA.debugLine="End Sub";
return "";
}
public String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 209;BA.debugLine="Private Sub Astreams_Terminated";
 //BA.debugLineNum = 210;BA.debugLine="CallSubDelayed(mParent, mEventName & \"_Terminated";
__c.CallSubDelayed(ba,_mparent,_meventname+"_Terminated");
 //BA.debugLineNum = 212;BA.debugLine="UpdateState (False)";
_updatestate(__c.False);
 //BA.debugLineNum = 213;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Admin As BluetoothAdmin";
_admin = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 8;BA.debugLine="Public Astreams As AsyncStreams";
_astreams = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 9;BA.debugLine="Private Serial As Serial";
_serial = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 11;BA.debugLine="Private mParent As Object";
_mparent = new Object();
 //BA.debugLineNum = 12;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 13;BA.debugLine="Private lblStatus As Label";
_lblstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Public foundDevices As List";
_founddevices = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 18;BA.debugLine="Type NameAndMac (Name As String, Mac As String)";
;
 //BA.debugLineNum = 20;BA.debugLine="Public BluetoothState, ConnectionState, DeviceFou";
_bluetoothstate = false;
_connectionstate = false;
_devicefound = false;
 //BA.debugLineNum = 23;BA.debugLine="Public CharSet = \"UTF-8\" As String";
_charset = "UTF-8";
 //BA.debugLineNum = 24;BA.debugLine="Private sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Public State As String";
_state = "";
 //BA.debugLineNum = 28;BA.debugLine="Public connected As Boolean";
_connected = false;
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
 //BA.debugLineNum = 78;BA.debugLine="Public Sub Close";
 //BA.debugLineNum = 79;BA.debugLine="If Astreams.IsInitialized Then Astreams.Close";
if (_astreams.IsInitialized()) { 
_astreams.Close();};
 //BA.debugLineNum = 80;BA.debugLine="If Serial.IsInitialized Then Serial.Disconnect";
if (_serial.IsInitialized()) { 
_serial.Disconnect();};
 //BA.debugLineNum = 82;BA.debugLine="UpdateState (False)";
_updatestate(__c.False);
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _connectto(b4a.HC05LedOnOff.bluetoothasynchstream._nameandmac _device) throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Public Sub ConnectTo (Device As NameAndMac)";
 //BA.debugLineNum = 88;BA.debugLine="Serial.Connect(Device.Mac)";
_serial.Connect(ba,_device.Mac /*String*/ );
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _parent,String _eventname,anywheresoftware.b4a.objects.LabelWrapper _statuslabel) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 38;BA.debugLine="Public Sub Initialize(Parent As Object, EventName";
 //BA.debugLineNum = 39;BA.debugLine="mParent = Parent";
_mparent = _parent;
 //BA.debugLineNum = 40;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 41;BA.debugLine="lblStatus = StatusLabel";
_lblstatus = _statuslabel;
 //BA.debugLineNum = 42;BA.debugLine="Admin.Initialize(\"Admin\")";
_admin.Initialize(ba,"Admin");
 //BA.debugLineNum = 43;BA.debugLine="Serial.Initialize(\"Serial\")";
_serial.Initialize("Serial");
 //BA.debugLineNum = 45;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 47;BA.debugLine="If Admin.IsEnabled = False Then";
if (_admin.IsEnabled()==__c.False) { 
 //BA.debugLineNum = 48;BA.debugLine="If Admin.Enable = False Then";
if (_admin.Enable()==__c.False) { 
 //BA.debugLineNum = 49;BA.debugLine="ToastMessageShow(\"Error enabling Bluetooth adap";
__c.ToastMessageShow(BA.ObjectToCharSequence("Error enabling Bluetooth adapter."),__c.True);
 }else {
 //BA.debugLineNum = 51;BA.debugLine="ToastMessageShow(\"Enabling Bluetooth adapter...";
__c.ToastMessageShow(BA.ObjectToCharSequence("Enabling Bluetooth adapter..."),__c.False);
 };
 }else {
 //BA.debugLineNum = 54;BA.debugLine="BluetoothState = True";
_bluetoothstate = __c.True;
 };
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Public Sub Open()";
 //BA.debugLineNum = 62;BA.debugLine="Serial.Connect(\"00:20:04:BD:2D:9B\")";
_serial.Connect(ba,"00:20:04:BD:2D:9B");
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public boolean  _searchfordevices() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Public Sub SearchForDevices As Boolean";
 //BA.debugLineNum = 94;BA.debugLine="foundDevices.Initialize";
_founddevices.Initialize();
 //BA.debugLineNum = 95;BA.debugLine="Return Admin.StartDiscovery";
if (true) return _admin.StartDiscovery();
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return false;
}
public String  _sendbytes(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Public Sub SendBytes(Buffer() As Byte)";
 //BA.debugLineNum = 177;BA.debugLine="Astreams.Write(Buffer)";
_astreams.Write(_buffer);
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _sendtext(String _text) throws Exception{
 //BA.debugLineNum = 183;BA.debugLine="Public Sub SendText(Text As String)";
 //BA.debugLineNum = 184;BA.debugLine="Astreams.Write(Text.GetBytes(CharSet))";
_astreams.Write(_text.getBytes(_charset));
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return "";
}
public String  _serial_connected(boolean _success) throws Exception{
String _msg = "";
 //BA.debugLineNum = 151;BA.debugLine="Sub Serial_Connected (Success As Boolean)";
 //BA.debugLineNum = 152;BA.debugLine="Private msg As String";
_msg = "";
 //BA.debugLineNum = 154;BA.debugLine="ProgressDialogHide";
__c.ProgressDialogHide();
 //BA.debugLineNum = 155;BA.debugLine="If Success = True Then";
if (_success==__c.True) { 
 //BA.debugLineNum = 156;BA.debugLine="If Astreams.IsInitialized Then Astreams.Close";
if (_astreams.IsInitialized()) { 
_astreams.Close();};
 //BA.debugLineNum = 157;BA.debugLine="Astreams.Initialize(Serial.InputStream, Serial.O";
_astreams.Initialize(ba,_serial.getInputStream(),_serial.getOutputStream(),"Astreams");
 //BA.debugLineNum = 158;BA.debugLine="msg = \"Connected\"";
_msg = "Connected";
 }else {
 //BA.debugLineNum = 164;BA.debugLine="Log(LastException.Message)";
__c.LogImpl("41048589",__c.LastException(ba).getMessage(),0);
 //BA.debugLineNum = 165;BA.debugLine="msg = LastException.Message";
_msg = __c.LastException(ba).getMessage();
 //BA.debugLineNum = 167;BA.debugLine="ToastMessageShow(\"Error connecting: \" & LastExce";
__c.ToastMessageShow(BA.ObjectToCharSequence("Error connecting: "+__c.LastException(ba).getMessage()),__c.True);
 };
 //BA.debugLineNum = 169;BA.debugLine="lblStatus.Text = msg";
_lblstatus.setText(BA.ObjectToCharSequence(_msg));
 //BA.debugLineNum = 172;BA.debugLine="UpdateState (Success)";
_updatestate(_success);
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public String  _updatestate(boolean _newstate) throws Exception{
 //BA.debugLineNum = 232;BA.debugLine="Sub UpdateState (NewState As Boolean)";
 //BA.debugLineNum = 233;BA.debugLine="connected = NewState";
_connected = _newstate;
 //BA.debugLineNum = 234;BA.debugLine="CallSub(Main, \"SetState\")";
__c.CallSubNew(ba,(Object)(_main.getObject()),"SetState");
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public String  _writebytes(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 193;BA.debugLine="Public Sub WriteBytes(Buffer() As Byte)";
 //BA.debugLineNum = 194;BA.debugLine="Astreams.Write(Buffer)";
_astreams.Write(_buffer);
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return "";
}
public String  _writetext(String _text) throws Exception{
 //BA.debugLineNum = 188;BA.debugLine="Public Sub WriteText(Text As String)";
 //BA.debugLineNum = 189;BA.debugLine="Astreams.Write(Text.GetBytes(CharSet))";
_astreams.Write(_text.getBytes(_charset));
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
