package b4a.HC05LedOnOff;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clxtoastmessage1 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.HC05LedOnOff.clxtoastmessage1");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.HC05LedOnOff.clxtoastmessage1.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.StringUtils _su = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbase = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mlbl = null;
public int _mpanelpos = 0;
public anywheresoftware.b4a.objects.collections.List _tmlist = null;
public anywheresoftware.b4a.objects.collections.Map _tempsettings = null;
public boolean _displaying = false;
public boolean _fading = false;
public anywheresoftware.b4a.objects.Timer _timer1 = null;
public int _tmpos_top = 0;
public int _tmpos_center = 0;
public int _tmpos_bottom = 0;
public int _vpos_top = 0;
public int _vpos_center = 0;
public int _vpos_bottom = 0;
public int _hpos_left = 0;
public int _hpos_center = 0;
public int _hpos_right = 0;
public b4a.HC05LedOnOff.main _main = null;
public b4a.HC05LedOnOff.starter _starter = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 20;BA.debugLine="Private su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 22;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 23;BA.debugLine="Private mBase As B4XView				'base panel from call";
_mbase = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private mPanel As B4XView				'panel holding the m";
_mpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private mLbl As B4XView					'message label";
_mlbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private mPanelPos As Int				'message position rel";
_mpanelpos = 0;
 //BA.debugLineNum = 27;BA.debugLine="Private TMList As List					'list of toast message";
_tmlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 28;BA.debugLine="Private tempSettings As Map				'temporary setting";
_tempsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 29;BA.debugLine="Private displaying As Boolean			'True = a TM is c";
_displaying = false;
 //BA.debugLineNum = 30;BA.debugLine="Private fading As Boolean				'True = fade effect";
_fading = false;
 //BA.debugLineNum = 31;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 32;BA.debugLine="Public CONST TMPOS_TOP As Int = 0		'constant to s";
_tmpos_top = (int) (0);
 //BA.debugLineNum = 33;BA.debugLine="Public CONST TMPOS_CENTER As Int = 1	'			\"			\"		\"";
_tmpos_center = (int) (1);
 //BA.debugLineNum = 34;BA.debugLine="Public CONST TMPOS_BOTTOM As Int = 2	'			\"			\"		\"";
_tmpos_bottom = (int) (2);
 //BA.debugLineNum = 35;BA.debugLine="Public CONST VPOS_TOP As Int = 0		'constant to ve";
_vpos_top = (int) (0);
 //BA.debugLineNum = 36;BA.debugLine="Public CONST VPOS_CENTER As Int = 1		'			\"			\"		\"";
_vpos_center = (int) (1);
 //BA.debugLineNum = 37;BA.debugLine="Public CONST VPOS_BOTTOM As Int = 2		'			\"			\"		\"";
_vpos_bottom = (int) (2);
 //BA.debugLineNum = 38;BA.debugLine="Public CONST HPOS_LEFT As Int = 0		'constant to h";
_hpos_left = (int) (0);
 //BA.debugLineNum = 39;BA.debugLine="Public CONST HPOS_CENTER As Int = 1		'			\"			\"		\"";
_hpos_center = (int) (1);
 //BA.debugLineNum = 40;BA.debugLine="Public CONST HPOS_RIGHT As Int = 2		'			\"			\"		\"";
_hpos_right = (int) (2);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _duplicatemap(anywheresoftware.b4a.objects.collections.Map _source) throws Exception{
anywheresoftware.b4a.objects.collections.Map _m1 = null;
String _key = "";
 //BA.debugLineNum = 290;BA.debugLine="Private Sub DuplicateMap(Source As Map) As Map";
 //BA.debugLineNum = 291;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 292;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 293;BA.debugLine="For Each key As String In Source.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _source.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_key = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 294;BA.debugLine="m1.Put(key, Source.Get(key))";
_m1.Put((Object)(_key),_source.Get((Object)(_key)));
 }
};
 //BA.debugLineNum = 296;BA.debugLine="Return m1";
if (true) return _m1;
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.B4XViewWrapper _base) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.objects.LabelWrapper _l1 = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub Initialize(Base As B4XView)";
 //BA.debugLineNum = 47;BA.debugLine="mBase = Base";
_mbase = _base;
 //BA.debugLineNum = 48;BA.debugLine="mBase.Tag = Me";
_mbase.setTag(this);
 //BA.debugLineNum = 49;BA.debugLine="Dim l1 As Label";
_l1 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 50;BA.debugLine="l1.Initialize(\"\")";
_l1.Initialize(ba,"");
 //BA.debugLineNum = 52;BA.debugLine="l1.SingleLine = False";
_l1.setSingleLine(__c.False);
 //BA.debugLineNum = 58;BA.debugLine="mLbl = l1";
_mlbl = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_l1.getObject()));
 //BA.debugLineNum = 59;BA.debugLine="mPanel = xui.CreatePanel(\"\")";
_mpanel = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 60;BA.debugLine="mPanel.Visible = True";
_mpanel.setVisible(__c.True);
 //BA.debugLineNum = 61;BA.debugLine="mPanel.bringtofront";
_mpanel.BringToFront();
 //BA.debugLineNum = 62;BA.debugLine="tempSettings = DuplicateMap(MakeDefaults)				'cre";
_tempsettings = _duplicatemap(_makedefaults());
 //BA.debugLineNum = 64;BA.debugLine="TMList.initialize";
_tmlist.Initialize();
 //BA.debugLineNum = 65;BA.debugLine="TMList.Add(DuplicateMap(tempSettings))					'save";
_tmlist.Add((Object)(_duplicatemap(_tempsettings).getObject()));
 //BA.debugLineNum = 66;BA.debugLine="displaying = False";
_displaying = __c.False;
 //BA.debugLineNum = 67;BA.debugLine="fading = False";
_fading = __c.False;
 //BA.debugLineNum = 68;BA.debugLine="timer1.Initialize(\"timer1\", 2000)						'timer def";
_timer1.Initialize(ba,"timer1",(long) (2000));
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.Map  _makedefaults() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m1 = null;
int _dipint = 0;
 //BA.debugLineNum = 72;BA.debugLine="Private Sub MakeDefaults As Map";
 //BA.debugLineNum = 73;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 74;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 76;BA.debugLine="If xui.IsB4A Then";
if (_xui.getIsB4A()) { 
 //BA.debugLineNum = 77;BA.debugLine="m1.Put(\"pColor\", xui.Color_ARGB(200,112,112,112)";
_m1.Put((Object)("pColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (112),(int) (112),(int) (112))));
 //BA.debugLineNum = 78;BA.debugLine="m1.Put(\"pBColor\",xui.Color_ARGB(200,112,112,112)";
_m1.Put((Object)("pBColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (112),(int) (112),(int) (112))));
 }else if(_xui.getIsB4i()) { 
 //BA.debugLineNum = 80;BA.debugLine="m1.Put(\"pColor\",xui.Color_ARGB(200,0,0,0))";
_m1.Put((Object)("pColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (0),(int) (0),(int) (0))));
 //BA.debugLineNum = 81;BA.debugLine="m1.Put(\"pBColor\",xui.Color_ARGB(200,0,0,0))";
_m1.Put((Object)("pBColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (0),(int) (0),(int) (0))));
 }else if(_xui.getIsB4J()) { 
 //BA.debugLineNum = 83;BA.debugLine="m1.Put(\"pColor\",xui.Color_ARGB(200,112,112,112))";
_m1.Put((Object)("pColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (112),(int) (112),(int) (112))));
 //BA.debugLineNum = 84;BA.debugLine="m1.Put(\"pBColor\",xui.Color_ARGB(200,112,112,112)";
_m1.Put((Object)("pBColor"),(Object)(_xui.Color_ARGB((int) (200),(int) (112),(int) (112),(int) (112))));
 };
 //BA.debugLineNum = 86;BA.debugLine="m1.Put(\"backgroundPadding\", 35dip)";
_m1.Put((Object)("backgroundPadding"),(Object)(__c.DipToCurrent((int) (35))));
 //BA.debugLineNum = 87;BA.debugLine="m1.Put(\"pBWidth\", 0dip)									'Background borde";
_m1.Put((Object)("pBWidth"),(Object)(__c.DipToCurrent((int) (0))));
 //BA.debugLineNum = 88;BA.debugLine="If xui.isB4a Then";
if (_xui.getIsB4A()) { 
 //BA.debugLineNum = 89;BA.debugLine="m1.Put(\"pBRadius\", 24dip)  'Background border ra";
_m1.Put((Object)("pBRadius"),(Object)(__c.DipToCurrent((int) (24))));
 }else if(_xui.getIsB4i()) { 
 //BA.debugLineNum = 91;BA.debugLine="m1.Put(\"pBRadius\", 10dip)  'Background border ra";
_m1.Put((Object)("pBRadius"),(Object)(__c.DipToCurrent((int) (10))));
 }else if(_xui.getIsB4J()) { 
 //BA.debugLineNum = 93;BA.debugLine="m1.Put(\"pBRadius\", 10dip)  'Background border ra";
_m1.Put((Object)("pBRadius"),(Object)(__c.DipToCurrent((int) (10))));
 };
 //BA.debugLineNum = 96;BA.debugLine="m1.Put(\"pPos\", TMPOS_CENTER)";
_m1.Put((Object)("pPos"),(Object)(_tmpos_center));
 //BA.debugLineNum = 98;BA.debugLine="If xui.IsB4A Then";
if (_xui.getIsB4A()) { 
 //BA.debugLineNum = 99;BA.debugLine="m1.Put(\"lTSize\", 14) 'Message label text size";
_m1.Put((Object)("lTSize"),(Object)(14));
 }else if(_xui.getIsB4i()) { 
 //BA.debugLineNum = 101;BA.debugLine="m1.Put(\"lTSize\", 16) 'Message label text size";
_m1.Put((Object)("lTSize"),(Object)(16));
 }else if(_xui.getIsB4J()) { 
 //BA.debugLineNum = 103;BA.debugLine="m1.Put(\"lTSize\", 14) 'Message label text size";
_m1.Put((Object)("lTSize"),(Object)(14));
 };
 //BA.debugLineNum = 105;BA.debugLine="m1.Put(\"labelPadding\", 5dip)				'";
_m1.Put((Object)("labelPadding"),(Object)(__c.DipToCurrent((int) (5))));
 //BA.debugLineNum = 106;BA.debugLine="m1.Put(\"lTColor\", (xui.Color_White))					'Message";
_m1.Put((Object)("lTColor"),(Object)((_xui.Color_White)));
 //BA.debugLineNum = 107;BA.debugLine="m1.Put(\"lHAlign\", (HPOS_CENTER))						'Message la";
_m1.Put((Object)("lHAlign"),(Object)((_hpos_center)));
 //BA.debugLineNum = 108;BA.debugLine="m1.Put(\"lVAlign\", (VPOS_CENTER))						'Message la";
_m1.Put((Object)("lVAlign"),(Object)((_vpos_center)));
 //BA.debugLineNum = 110;BA.debugLine="m1.Put(\"dShort\", 2000)									'Message  display";
_m1.Put((Object)("dShort"),(Object)(2000));
 //BA.debugLineNum = 111;BA.debugLine="m1.Put(\"dLong\", 3000)									'Message  display t";
_m1.Put((Object)("dLong"),(Object)(3000));
 //BA.debugLineNum = 113;BA.debugLine="Dim dipint As Int = mBase.Width / 9";
_dipint = (int) (_mbase.getWidth()/(double)9);
 //BA.debugLineNum = 114;BA.debugLine="m1.Put(\"horizMinMargin\", dipint)						'horizontal";
_m1.Put((Object)("horizMinMargin"),(Object)(_dipint));
 //BA.debugLineNum = 115;BA.debugLine="Dim dipint As Int = 60 * (100dip/100)";
_dipint = (int) (60*(__c.DipToCurrent((int) (100))/(double)100));
 //BA.debugLineNum = 116;BA.debugLine="m1.Put(\"bottomMargin\", dipint)";
_m1.Put((Object)("bottomMargin"),(Object)(_dipint));
 //BA.debugLineNum = 117;BA.debugLine="m1.Put(\"verticalOffset\", 0)								'vertical offs";
_m1.Put((Object)("verticalOffset"),(Object)(0));
 //BA.debugLineNum = 118;BA.debugLine="Return m1";
if (true) return _m1;
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return null;
}
public String  _sethorizontalminmargin(int _horpercent) throws Exception{
int _setting = 0;
 //BA.debugLineNum = 144;BA.debugLine="Public Sub SetHorizontalMinMargin(horpercent As In";
 //BA.debugLineNum = 145;BA.debugLine="If horpercent >= 5 And horpercent < 50 Then";
if (_horpercent>=5 && _horpercent<50) { 
 //BA.debugLineNum = 146;BA.debugLine="Dim setting As Int = mBase.Width * (horpercent/1";
_setting = (int) (_mbase.getWidth()*(_horpercent/(double)100));
 //BA.debugLineNum = 147;BA.debugLine="tempSettings.Put(\"horizMinMargin\", setting)";
_tempsettings.Put((Object)("horizMinMargin"),(Object)(_setting));
 };
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public String  _settmbackground(Object _backgroundcolor,double _borderwidth,Object _bordercolor,double _bordercornerradius) throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Public Sub SetTMBackground(BackgroundColor As Obje";
 //BA.debugLineNum = 153;BA.debugLine="tempSettings.Put(\"pColor\",xui.PaintOrColorToColor";
_tempsettings.Put((Object)("pColor"),(Object)(_xui.PaintOrColorToColor(_backgroundcolor)));
 //BA.debugLineNum = 154;BA.debugLine="tempSettings.Put(\"pBColor\",xui.PaintOrColorToColo";
_tempsettings.Put((Object)("pBColor"),(Object)(_xui.PaintOrColorToColor(_bordercolor)));
 //BA.debugLineNum = 155;BA.debugLine="tempSettings.Put(\"pBWidth\", BorderWidth)";
_tempsettings.Put((Object)("pBWidth"),(Object)(_borderwidth));
 //BA.debugLineNum = 156;BA.debugLine="tempSettings.Put(\"pBRadius\", BorderCornerRadius)";
_tempsettings.Put((Object)("pBRadius"),(Object)(_bordercornerradius));
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
return "";
}
public String  _settmdefaults() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
 //BA.debugLineNum = 126;BA.debugLine="Public Sub SetTMDefaults";
 //BA.debugLineNum = 127;BA.debugLine="Dim m As Map = TMList.Get(0)";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (anywheresoftware.b4a.objects.collections.Map.MyMap)(_tmlist.Get((int) (0))));
 //BA.debugLineNum = 128;BA.debugLine="tempSettings = DuplicateMap(m)";
_tempsettings = _duplicatemap(_m);
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return "";
}
public String  _settmduration(int _shortduration,int _longduration) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Public Sub SetTMDuration(ShortDuration As Int, Lon";
 //BA.debugLineNum = 133;BA.debugLine="tempSettings.Put(\"dShort\", ShortDuration)";
_tempsettings.Put((Object)("dShort"),(Object)(_shortduration));
 //BA.debugLineNum = 134;BA.debugLine="tempSettings.Put(\"dLong\", LongDuration)";
_tempsettings.Put((Object)("dLong"),(Object)(_longduration));
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public String  _settmposition(int _apos) throws Exception{
 //BA.debugLineNum = 166;BA.debugLine="Public Sub SetTMPosition(aPos As Int)";
 //BA.debugLineNum = 167;BA.debugLine="If aPos >=0 And aPos <= 2 Then tempSettings.Put(\"";
if (_apos>=0 && _apos<=2) { 
_tempsettings.Put((Object)("pPos"),(Object)(_apos));};
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _settmtextprop(double _asize,Object _acolor) throws Exception{
 //BA.debugLineNum = 160;BA.debugLine="Public Sub SetTMTextProp(aSize As Double, aColor A";
 //BA.debugLineNum = 161;BA.debugLine="tempSettings.Put(\"lTSize\", aSize)";
_tempsettings.Put((Object)("lTSize"),(Object)(_asize));
 //BA.debugLineNum = 162;BA.debugLine="tempSettings.Put(\"lTColor\", (xui.PaintOrColorToCo";
_tempsettings.Put((Object)("lTColor"),(Object)((_xui.PaintOrColorToColor(_acolor))));
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return "";
}
public String  _setverticaloffset(int _off) throws Exception{
int _setting = 0;
 //BA.debugLineNum = 138;BA.debugLine="Public Sub SetVerticalOffset(off As Int)";
 //BA.debugLineNum = 139;BA.debugLine="Dim setting As Int = off * 100dip/100";
_setting = (int) (_off*__c.DipToCurrent((int) (100))/(double)100);
 //BA.debugLineNum = 140;BA.debugLine="tempSettings.Put(\"verticalOffset\", setting)";
_tempsettings.Put((Object)("verticalOffset"),(Object)(_setting));
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public String  _show(String _message,boolean _longduration) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.objects.B4XCanvas _canvas = null;
float _fsize = 0f;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _fnt = null;
int _lpadding = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _sizeoflabel = null;
int _bpadding = 0;
int _pd = 0;
 //BA.debugLineNum = 173;BA.debugLine="Public Sub Show (Message As String, LongDuration A";
 //BA.debugLineNum = 175;BA.debugLine="mPanel.RemoveAllViews";
_mpanel.RemoveAllViews();
 //BA.debugLineNum = 177;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 178;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, mBase.width, 40dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_mbase.getWidth(),__c.DipToCurrent((int) (40)));
 //BA.debugLineNum = 179;BA.debugLine="Private canvas As B4XCanvas";
_canvas = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 180;BA.debugLine="canvas.Initialize(p)";
_canvas.Initialize(_p);
 //BA.debugLineNum = 181;BA.debugLine="Dim fsize As Float = tempSettings.get(\"lTSize\")";
_fsize = (float)(BA.ObjectToNumber(_tempsettings.Get((Object)("lTSize"))));
 //BA.debugLineNum = 182;BA.debugLine="Dim fnt As B4XFont = xui.CreateDefaultFont(fsize)";
_fnt = _xui.CreateDefaultFont(_fsize);
 //BA.debugLineNum = 184;BA.debugLine="Dim lpadding As Int = tempSettings.Get(\"labelPadd";
_lpadding = (int)(BA.ObjectToNumber(_tempsettings.Get((Object)("labelPadding"))));
 //BA.debugLineNum = 185;BA.debugLine="Dim sizeoflabel As B4XRect = canvas.MeasureText(M";
_sizeoflabel = _canvas.MeasureText(_message,_fnt);
 //BA.debugLineNum = 186;BA.debugLine="sizeoflabel.Width = sizeoflabel.Width + lpadding";
_sizeoflabel.setWidth((int) (_sizeoflabel.getWidth()+_lpadding));
 //BA.debugLineNum = 187;BA.debugLine="Dim bpadding As Int = tempSettings.Get(\"backgroun";
_bpadding = (int)(BA.ObjectToNumber(_tempsettings.Get((Object)("backgroundPadding"))));
 //BA.debugLineNum = 190;BA.debugLine="If tempSettings.Get(\"horizMinMargin\") > (mBase.Wi";
if ((double)(BA.ObjectToNumber(_tempsettings.Get((Object)("horizMinMargin"))))>(_mbase.getWidth()-(_sizeoflabel.getWidth()+_bpadding))/(double)2) { 
 //BA.debugLineNum = 192;BA.debugLine="sizeoflabel.Width = mBase.Width - tempSettings.G";
_sizeoflabel.setWidth((int) (_mbase.getWidth()-(double)(BA.ObjectToNumber(_tempsettings.Get((Object)("horizMinMargin"))))*2-_bpadding));
 };
 //BA.debugLineNum = 195;BA.debugLine="Dim pd As Int = tempSettings.Get(\"backgroundPaddi";
_pd = (int)(BA.ObjectToNumber(_tempsettings.Get((Object)("backgroundPadding"))));
 //BA.debugLineNum = 196;BA.debugLine="mPanel.AddView(mLbl, pd/2, 0dip, sizeoflabel.widt";
_mpanel.AddView((android.view.View)(_mlbl.getObject()),(int) (_pd/(double)2),__c.DipToCurrent((int) (0)),(int) (_sizeoflabel.getWidth()),__c.DipToCurrent((int) (40)));
 //BA.debugLineNum = 198;BA.debugLine="tempSettings.Put(\"lText\", Message)";
_tempsettings.Put((Object)("lText"),(Object)(_message));
 //BA.debugLineNum = 199;BA.debugLine="tempSettings.Put(\"tmfade\", True)";
_tempsettings.Put((Object)("tmfade"),(Object)(__c.True));
 //BA.debugLineNum = 200;BA.debugLine="tempSettings.Put(\"tmdur\", LongDuration)";
_tempsettings.Put((Object)("tmdur"),(Object)(_longduration));
 //BA.debugLineNum = 201;BA.debugLine="TMList.Add(DuplicateMap(tempSettings))";
_tmlist.Add((Object)(_duplicatemap(_tempsettings).getObject()));
 //BA.debugLineNum = 202;BA.debugLine="If displaying Then Return";
if (_displaying) { 
if (true) return "";};
 //BA.debugLineNum = 203;BA.debugLine="ShowMessage";
_showmessage();
 //BA.debugLineNum = 204;BA.debugLine="End Sub";
return "";
}
public String  _showmessage() throws Exception{
anywheresoftware.b4a.objects.collections.Map _m = null;
int _lduration = 0;
int _sduration = 0;
int _bp = 0;
int _mpanelleft = 0;
int _mpanelwidth = 0;
int _voff = 0;
 //BA.debugLineNum = 207;BA.debugLine="Private Sub ShowMessage";
 //BA.debugLineNum = 208;BA.debugLine="Dim m As Map = TMList.Get(1)										'item #1 =";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (anywheresoftware.b4a.objects.collections.Map.MyMap)(_tmlist.Get((int) (1))));
 //BA.debugLineNum = 210;BA.debugLine="mPanel.SetColorAndBorder(xui.PaintOrColorToColor(";
_mpanel.SetColorAndBorder(_xui.PaintOrColorToColor(_m.Get((Object)("pColor"))),(int)(BA.ObjectToNumber(_m.Get((Object)("pBWidth")))),_xui.PaintOrColorToColor(_m.Get((Object)("pBColor"))),(int)(BA.ObjectToNumber(_m.Get((Object)("pBRadius")))));
 //BA.debugLineNum = 211;BA.debugLine="mLbl.TextSize = m.Get(\"lTSize\")";
_mlbl.setTextSize((float)(BA.ObjectToNumber(_m.Get((Object)("lTSize")))));
 //BA.debugLineNum = 212;BA.debugLine="mLbl.SetTextAlignment(\"CENTER\", \"CENTER\")";
_mlbl.SetTextAlignment("CENTER","CENTER");
 //BA.debugLineNum = 213;BA.debugLine="mLbl.TextColor = xui.PaintOrColorToColor(m.Get(\"l";
_mlbl.setTextColor(_xui.PaintOrColorToColor(_m.Get((Object)("lTColor"))));
 //BA.debugLineNum = 214;BA.debugLine="mLbl.Text = m.Get(\"lText\") 'Message";
_mlbl.setText(BA.ObjectToCharSequence(_m.Get((Object)("lText"))));
 //BA.debugLineNum = 215;BA.debugLine="mPanelPos = m.Get(\"pPos\")";
_mpanelpos = (int)(BA.ObjectToNumber(_m.Get((Object)("pPos"))));
 //BA.debugLineNum = 217;BA.debugLine="Private LDuration, SDuration As Int";
_lduration = 0;
_sduration = 0;
 //BA.debugLineNum = 218;BA.debugLine="SDuration = m.get(\"dShort\")";
_sduration = (int)(BA.ObjectToNumber(_m.Get((Object)("dShort"))));
 //BA.debugLineNum = 219;BA.debugLine="LDuration = m.get(\"dLong\")";
_lduration = (int)(BA.ObjectToNumber(_m.Get((Object)("dLong"))));
 //BA.debugLineNum = 226;BA.debugLine="mLbl.Height = su.MeasureMultilineTextHeight(mLbl,";
_mlbl.setHeight((int) (_su.MeasureMultilineTextHeight((android.widget.TextView)(_mlbl.getObject()),BA.ObjectToCharSequence(_mlbl.getText()))+2*__c.DipToCurrent((int) (14))));
 //BA.debugLineNum = 233;BA.debugLine="mPanel.Height = mLbl.Height + 2dip 'accounts for";
_mpanel.setHeight((int) (_mlbl.getHeight()+__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 235;BA.debugLine="Dim bp As Int = tempSettings.Get(\"backgroundPaddi";
_bp = (int)(BA.ObjectToNumber(_tempsettings.Get((Object)("backgroundPadding"))));
 //BA.debugLineNum = 236;BA.debugLine="Dim mPanelLeft As Int = (mBase.Width - mLbl.width";
_mpanelleft = (int) ((_mbase.getWidth()-_mlbl.getWidth()-_bp)/(double)2);
 //BA.debugLineNum = 237;BA.debugLine="Dim mPanelWidth As Int = mLbl.width + bp";
_mpanelwidth = (int) (_mlbl.getWidth()+_bp);
 //BA.debugLineNum = 238;BA.debugLine="Dim voff As Int = tempSettings.Get(\"verticalOffse";
_voff = (int)(BA.ObjectToNumber(_tempsettings.Get((Object)("verticalOffset"))));
 //BA.debugLineNum = 240;BA.debugLine="Select mPanelPos";
switch (BA.switchObjectToInt(_mpanelpos,_tmpos_top,_tmpos_center,_tmpos_bottom)) {
case 0: {
 //BA.debugLineNum = 242;BA.debugLine="mBase.AddView(mPanel, mPanelLeft, 5dip + voff,";
_mbase.AddView((android.view.View)(_mpanel.getObject()),_mpanelleft,(int) (__c.DipToCurrent((int) (5))+_voff),_mpanelwidth,_mlbl.getHeight());
 break; }
case 1: {
 //BA.debugLineNum = 244;BA.debugLine="mBase.AddView(mPanel, mPanelLeft, (mBase.Height";
_mbase.AddView((android.view.View)(_mpanel.getObject()),_mpanelleft,(int) ((_mbase.getHeight()-_mpanel.getHeight())/(double)2+_voff),_mpanelwidth,_mlbl.getHeight());
 break; }
case 2: {
 //BA.debugLineNum = 246;BA.debugLine="mBase.AddView(mPanel, mPanelLeft, mBase.Height-";
_mbase.AddView((android.view.View)(_mpanel.getObject()),_mpanelleft,(int) (_mbase.getHeight()-_mpanel.getHeight()-(double)(BA.ObjectToNumber(_m.Get((Object)("bottomMargin"))))+_voff),_mpanelwidth,_mlbl.getHeight());
 break; }
}
;
 //BA.debugLineNum = 248;BA.debugLine="fading = tempSettings.get(\"tmfade\")";
_fading = BA.ObjectToBoolean(_tempsettings.Get((Object)("tmfade")));
 //BA.debugLineNum = 249;BA.debugLine="If fading Then	mPanel.SetVisibleAnimated(400, Tru";
if (_fading) { 
_mpanel.SetVisibleAnimated((int) (400),__c.True);}
else {
_mpanel.SetVisibleAnimated((int) (0),__c.True);};
 //BA.debugLineNum = 250;BA.debugLine="displaying = True";
_displaying = __c.True;
 //BA.debugLineNum = 251;BA.debugLine="If tempSettings.get(\"tmdur\") Then timer1.Interval";
if (BA.ObjectToBoolean(_tempsettings.Get((Object)("tmdur")))) { 
_timer1.setInterval((long) (_lduration));}
else {
_timer1.setInterval((long) (_sduration));};
 //BA.debugLineNum = 252;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(__c.True);
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return "";
}
public void  _timer1_tick() throws Exception{
ResumableSub_timer1_tick rsub = new ResumableSub_timer1_tick(this);
rsub.resume(ba, null);
}
public static class ResumableSub_timer1_tick extends BA.ResumableSub {
public ResumableSub_timer1_tick(b4a.HC05LedOnOff.clxtoastmessage1 parent) {
this.parent = parent;
}
b4a.HC05LedOnOff.clxtoastmessage1 parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 257;BA.debugLine="If fading Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._fading) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 258;BA.debugLine="mPanel.SetVisibleAnimated(400, False)";
parent._mpanel.SetVisibleAnimated((int) (400),parent.__c.False);
 //BA.debugLineNum = 259;BA.debugLine="Sleep(500)";
parent.__c.Sleep(ba,this,(int) (500));
this.state = 13;
return;
case 13:
//C
this.state = 4;
;
 //BA.debugLineNum = 260;BA.debugLine="fading = False";
parent._fading = parent.__c.False;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 262;BA.debugLine="timer1.Enabled = False";
parent._timer1.setEnabled(parent.__c.False);
 //BA.debugLineNum = 263;BA.debugLine="mPanel.RemoveViewFromParent";
parent._mpanel.RemoveViewFromParent();
 //BA.debugLineNum = 264;BA.debugLine="mBase.Tag = Null";
parent._mbase.setTag(parent.__c.Null);
 //BA.debugLineNum = 265;BA.debugLine="TMList.RemoveAt(1)";
parent._tmlist.RemoveAt((int) (1));
 //BA.debugLineNum = 266;BA.debugLine="If TMList.Size > 1 Then ShowMessage Else displayi";
if (true) break;

case 5:
//if
this.state = 12;
if (parent._tmlist.getSize()>1) { 
this.state = 7;
;}
else {
this.state = 9;
;}if (true) break;

case 7:
//C
this.state = 12;
parent._showmessage();
if (true) break;

case 9:
//C
this.state = 12;
parent._displaying = parent.__c.False;
if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
